// NicheScope — Tweaks Panel integration

const { useState: useState6 } = React;

function NicheScopeTweaks({ tweaks, setTweak }) {
  return (
    <TweaksPanel onClose={() => window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*')}>
      <TweakSection title="Accent Colors">
        <TweakColor label="Cyan (primary)" id="colorCyan" value={tweaks.colorCyan} onChange={v => setTweak('colorCyan', v)} />
        <TweakColor label="Amber (opportunity)" id="colorAmber" value={tweaks.colorAmber} onChange={v => setTweak('colorAmber', v)} />
        <TweakColor label="Rose (risk)" id="colorRose" value={tweaks.colorRose} onChange={v => setTweak('colorRose', v)} />
      </TweakSection>
      <TweakSection title="Layout">
        <TweakToggle label="Show sponsored badges" id="showSponsored" value={tweaks.showSponsored} onChange={v => setTweak('showSponsored', v)} />
        <TweakToggle label="Show AI insights" id="showAI" value={tweaks.showAI} onChange={v => setTweak('showAI', v)} />
        <TweakToggle label="Compact table rows" id="compactTable" value={tweaks.compactTable} onChange={v => setTweak('compactTable', v)} />
      </TweakSection>
      <TweakSection title="Data">
        <TweakRadio
          label="Revenue estimate"
          id="revenueMode"
          value={tweaks.revenueMode}
          options={[{ label: "Mid", value: "mid" }, { label: "Low", value: "low" }, { label: "High", value: "high" }]}
          onChange={v => setTweak('revenueMode', v)}
        />
        <TweakSlider label="Products shown" id="productCount" value={tweaks.productCount} min={3} max={10} step={1} onChange={v => setTweak('productCount', v)} />
      </TweakSection>
      <TweakSection title="Start screen">
        <TweakButton label="Reset to PIN gate" onClick={() => {
          window.__resetToPin && window.__resetToPin();
          window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
        }} />
        <TweakButton label="Go to URL input" onClick={() => {
          window.__goToUrl && window.__goToUrl();
          window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
        }} />
      </TweakSection>
    </TweaksPanel>
  );
}

Object.assign(window, { NicheScopeTweaks });
