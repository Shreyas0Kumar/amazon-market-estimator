// NicheScope — PIN Gate, URL Input, Loading screens

const { useState, useEffect, useRef } = React;

// ─── Logo ────────────────────────────────────────────────────────────────────
function Logo({ size = "md" }) {
  const sizes = { sm: { dot: 7, text: 15 }, md: { dot: 9, text: 18 }, lg: { dot: 12, text: 24 } };
  const s = sizes[size] || sizes.md;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{
        width: s.dot, height: s.dot, borderRadius: "50%",
        background: "#06b6d4",
        boxShadow: "0 0 10px #06b6d4aa, 0 0 20px #06b6d455"
      }} />
      <span style={{
        fontFamily: "'DM Sans', sans-serif",
        fontWeight: 600,
        fontSize: s.text,
        color: "#f1f5f9",
        letterSpacing: "-0.01em"
      }}>NicheScope</span>
    </div>
  );
}

// ─── PIN Gate ─────────────────────────────────────────────────────────────────
function PinGate({ onSuccess }) {
  const [digits, setDigits] = useState(["", "", "", ""]);
  const [focusIndex, setFocusIndex] = useState(0);
  const [shake, setShake] = useState(false);
  const [success, setSuccess] = useState(false);
  const refs = [useRef(), useRef(), useRef(), useRef()];
  const CORRECT_PIN = "1234";

  useEffect(() => { refs[0].current?.focus(); }, []);

  function handleKey(i, e) {
    if (e.key === "Backspace") {
      const next = [...digits];
      if (next[i]) { next[i] = ""; setDigits(next); }
      else if (i > 0) { next[i - 1] = ""; setDigits(next); setFocusIndex(i - 1); refs[i - 1].current?.focus(); }
      return;
    }
    if (!/^\d$/.test(e.key)) return;
    const next = [...digits];
    next[i] = e.key;
    setDigits(next);
    if (i < 3) { setFocusIndex(i + 1); refs[i + 1].current?.focus(); }
    else {
      const pin = next.join("");
      if (pin === CORRECT_PIN) {
        setSuccess(true);
        setTimeout(() => onSuccess(), 500);
      } else {
        setShake(true);
        setTimeout(() => { setShake(false); setDigits(["", "", "", ""]); setFocusIndex(0); refs[0].current?.focus(); }, 600);
      }
    }
  }

  return (
    <div style={{
      minHeight: "100vh", background: "#0a0f1e",
      display: "flex", alignItems: "center", justifyContent: "center",
      position: "relative", overflow: "hidden"
    }}>
      {/* Grid texture */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(rgba(6,182,212,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.03) 1px, transparent 1px)",
        backgroundSize: "40px 40px",
        pointerEvents: "none"
      }} />
      {/* Radial glow */}
      <div style={{
        position: "absolute", top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
        width: 600, height: 600,
        background: "radial-gradient(circle, rgba(6,182,212,0.08) 0%, transparent 70%)",
        pointerEvents: "none"
      }} />

      <div style={{
        position: "relative", zIndex: 1,
        background: "rgba(15,23,42,0.85)",
        border: "1px solid #1e293b",
        borderRadius: 20,
        padding: "48px 52px",
        display: "flex", flexDirection: "column", alignItems: "center", gap: 32,
        backdropFilter: "blur(20px)",
        boxShadow: "0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(6,182,212,0.08)",
        animation: shake ? "shake 0.5s" : success ? "fadeUp 0.4s ease" : "none"
      }}>
        <Logo size="md" />
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "#64748b", letterSpacing: "0.08em", textTransform: "uppercase" }}>
            Amazon Market Intelligence
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 }}>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 14, color: "#94a3b8" }}>
            Enter your access PIN
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            {digits.map((d, i) => (
              <input
                key={i}
                ref={refs[i]}
                type="password"
                inputMode="numeric"
                maxLength={1}
                value={d}
                onChange={() => {}}
                onKeyDown={(e) => handleKey(i, e)}
                onFocus={() => setFocusIndex(i)}
                style={{
                  width: 56, height: 64,
                  background: "#0f172a",
                  border: `1px solid ${focusIndex === i ? "#06b6d4" : "#1e293b"}`,
                  borderRadius: 12,
                  textAlign: "center",
                  fontSize: 24,
                  color: "#f1f5f9",
                  fontFamily: "'Space Mono', monospace",
                  outline: "none",
                  boxShadow: focusIndex === i ? "0 0 0 3px rgba(6,182,212,0.15), 0 0 16px rgba(6,182,212,0.1)" : "none",
                  transition: "border-color 0.15s, box-shadow 0.15s",
                  caretColor: "transparent",
                  cursor: "default"
                }}
              />
            ))}
          </div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "#334155" }}>
            Hint: 1234
          </div>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%,100%{transform:translateX(0)} 20%{transform:translateX(-8px)} 40%{transform:translateX(8px)} 60%{transform:translateX(-6px)} 80%{transform:translateX(6px)}
        }
        @keyframes fadeUp {
          from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)}
        }
      `}</style>
    </div>
  );
}

// ─── URL Input ────────────────────────────────────────────────────────────────
const LOADING_MESSAGES = [
  "Fetching top products...",
  "Calculating revenue estimates...",
  "Analyzing competitive landscape...",
  "Generating market insights...",
  "Finalizing your report...",
];

function UrlInput({ onAnalyze }) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [msgIndex, setMsgIndex] = useState(0);
  const [msgVisible, setMsgVisible] = useState(true);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!loading) return;
    // Progress animation
    let p = 0;
    const prog = setInterval(() => {
      p += Math.random() * 4 + 1;
      if (p >= 95) { clearInterval(prog); p = 95; }
      setProgress(p);
    }, 200);

    // Message cycling
    let idx = 0;
    const cycle = setInterval(() => {
      setMsgVisible(false);
      setTimeout(() => {
        idx = (idx + 1) % LOADING_MESSAGES.length;
        setMsgIndex(idx);
        setMsgVisible(true);
      }, 300);
    }, 2000);

    // Complete after 3.5s
    const done = setTimeout(() => {
      clearInterval(prog);
      clearInterval(cycle);
      setProgress(100);
      setTimeout(() => onAnalyze(), 400);
    }, 3500);

    return () => { clearInterval(prog); clearInterval(cycle); clearTimeout(done); };
  }, [loading]);

  function handleSubmit(query) {
    if (!query.trim()) return;
    setUrl(query);
    setLoading(true);
    setMsgIndex(0);
    setMsgVisible(true);
    setProgress(0);
  }

  return (
    <div style={{
      minHeight: "100vh", background: "#0a0f1e",
      display: "flex", alignItems: "center", justifyContent: "center",
      flexDirection: "column", gap: 0,
      position: "relative", overflow: "hidden"
    }}>
      {/* Grid texture */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "linear-gradient(rgba(6,182,212,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(6,182,212,0.025) 1px, transparent 1px)",
        backgroundSize: "40px 40px", pointerEvents: "none"
      }} />
      <div style={{
        position: "absolute", top: "35%", left: "50%",
        transform: "translate(-50%, -50%)",
        width: 800, height: 500,
        background: "radial-gradient(ellipse, rgba(6,182,212,0.06) 0%, transparent 65%)",
        pointerEvents: "none"
      }} />

      <div style={{
        position: "relative", zIndex: 1,
        display: "flex", flexDirection: "column", alignItems: "center",
        gap: 40, maxWidth: 640, width: "90%", padding: "0 20px"
      }}>
        <Logo size="md" />

        <div style={{ textAlign: "center" }}>
          <h1 style={{
            fontFamily: "'DM Sans', sans-serif",
            fontSize: "clamp(28px, 4vw, 42px)",
            fontWeight: 700, color: "#f1f5f9",
            margin: 0, lineHeight: 1.15,
            letterSpacing: "-0.02em"
          }}>
            What market are you<br />
            <span style={{ color: "#06b6d4" }}>entering?</span>
          </h1>
          <p style={{
            fontFamily: "'DM Sans', sans-serif",
            fontSize: 16, color: "#64748b",
            marginTop: 12, marginBottom: 0
          }}>
            Paste any Amazon search, category, or Best Sellers URL
          </p>
        </div>

        <div style={{ width: "100%" }}>
          {loading ? (
            <div style={{
              background: "#0f172a",
              border: "1px solid #1e293b",
              borderRadius: 16, padding: "24px 28px",
              display: "flex", flexDirection: "column", gap: 16
            }}>
              <div style={{
                height: 3, background: "#1e293b", borderRadius: 99, overflow: "hidden"
              }}>
                <div style={{
                  height: "100%",
                  width: `${progress}%`,
                  background: "linear-gradient(90deg, #06b6d4, #818cf8)",
                  borderRadius: 99,
                  transition: "width 0.3s ease",
                  boxShadow: "0 0 8px rgba(6,182,212,0.6)"
                }} />
              </div>
              <div style={{
                fontFamily: "'DM Sans', sans-serif",
                fontSize: 14, color: "#94a3b8",
                textAlign: "center",
                opacity: msgVisible ? 1 : 0,
                transition: "opacity 0.3s ease"
              }}>
                {LOADING_MESSAGES[msgIndex]}
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <div style={{ display: "flex", gap: 10 }}>
                <input
                  type="text"
                  value={url}
                  onChange={e => setUrl(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleSubmit(url)}
                  placeholder="https://www.amazon.com/s?k=bamboo+cutting+board"
                  style={{
                    flex: 1,
                    background: "#0f172a",
                    border: "1px solid #1e293b",
                    borderRadius: 12,
                    padding: "15px 20px",
                    fontFamily: "'DM Sans', sans-serif",
                    fontSize: 14, color: "#f1f5f9",
                    outline: "none",
                    transition: "border-color 0.15s, box-shadow 0.15s"
                  }}
                  onFocus={e => { e.target.style.borderColor = "#06b6d4"; e.target.style.boxShadow = "0 0 0 3px rgba(6,182,212,0.12)"; }}
                  onBlur={e => { e.target.style.borderColor = "#1e293b"; e.target.style.boxShadow = "none"; }}
                />
                <button
                  onClick={() => handleSubmit(url)}
                  style={{
                    background: "#06b6d4",
                    border: "none", borderRadius: 12,
                    padding: "15px 24px",
                    fontFamily: "'DM Sans', sans-serif",
                    fontWeight: 600, fontSize: 14,
                    color: "#0a0f1e", cursor: "pointer",
                    whiteSpace: "nowrap",
                    transition: "background 0.15s, transform 0.1s"
                  }}
                  onMouseEnter={e => { e.target.style.background = "#22d3ee"; }}
                  onMouseLeave={e => { e.target.style.background = "#06b6d4"; }}
                  onMouseDown={e => { e.target.style.transform = "scale(0.97)"; }}
                  onMouseUp={e => { e.target.style.transform = "scale(1)"; }}
                >
                  Analyze Market →
                </button>
              </div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "#475569" }}>Try:</span>
                {["Standing Desks", "Air Fryers", "Yoga Mats"].map(chip => (
                  <button key={chip} onClick={() => handleSubmit(chip)} style={{
                    background: "transparent",
                    border: "1px solid #1e293b",
                    borderRadius: 99, padding: "4px 12px",
                    fontFamily: "'DM Sans', sans-serif",
                    fontSize: 12, color: "#64748b",
                    cursor: "pointer",
                    transition: "border-color 0.15s, color 0.15s"
                  }}
                    onMouseEnter={e => { e.target.style.borderColor = "#06b6d4"; e.target.style.color = "#06b6d4"; }}
                    onMouseLeave={e => { e.target.style.borderColor = "#1e293b"; e.target.style.color = "#64748b"; }}
                  >
                    {chip}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={{
        position: "fixed", bottom: 24, left: 28,
        fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "#334155"
      }}>
        <a href="#" style={{ color: "#334155", textDecoration: "none" }}
          onMouseEnter={e => e.target.style.color = "#64748b"}
          onMouseLeave={e => e.target.style.color = "#334155"}
        >
          How estimates work ↗
        </a>
      </div>
    </div>
  );
}

Object.assign(window, { Logo, PinGate, UrlInput });
