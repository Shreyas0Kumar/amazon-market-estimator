// NicheScope — Distributions, Brand Leaderboard, AI Insights, Recommendations, Risks, Footer

const { useState: useState4, useEffect: useEffect4, useRef: useRef4 } = React;

// ─── Distribution Charts ───────────────────────────────────────────────────────
function DistributionChart({ data }) {
  const [activeTab, setActiveTab4] = useState4("price");
  const [animated, setAnimated4] = useState4(false);

  useEffect4(() => {
    const t = setTimeout(() => setAnimated4(true), 100);
    return () => clearTimeout(t);
  }, [activeTab]);

  useEffect4(() => {
    setAnimated4(false);
  }, [activeTab]);

  const tabs = [
    { key: "price", label: "Price", data: data.priceDistribution },
    { key: "rating", label: "Rating", data: data.ratingDistribution },
    { key: "reviews", label: "Reviews", data: data.reviewDistribution },
  ];

  const active = tabs.find(t => t.key === activeTab);
  const maxCount = Math.max(...active.data.map(d => d.count));

  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, padding: "20px 24px", flex: 1 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)" }}>
          Distributions
        </span>
        <div style={{ display: "flex", background: "var(--bg-deep)", borderRadius: 99, padding: 3, gap: 2 }}>
          {tabs.map(t => (
            <button key={t.key} onClick={() => setActiveTab4(t.key)} style={{
              padding: "5px 14px", borderRadius: 99, border: "none",
              background: activeTab === t.key ? "var(--border)" : "transparent",
              fontFamily: "'DM Sans', sans-serif", fontSize: 12,
              color: activeTab === t.key ? "var(--text-base)" : "var(--border-mid)",
              cursor: "pointer", transition: "background 0.15s, color 0.15s"
            }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, alignItems: "flex-end", height: 120, padding: "0 4px" }}>
        {active.data.map((d, i) => {
          const pct = maxCount > 0 ? (d.count / maxCount) : 0;
          return (
            <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <div style={{ width: "100%", display: "flex", flexDirection: "column", justifyContent: "flex-end", height: 90 }}>
                <div style={{
                  width: "100%", borderRadius: "4px 4px 0 0",
                  height: animated ? `${pct * 90}px` : "0px",
                  background: "linear-gradient(180deg, #06b6d4, #818cf8)",
                  transition: `height 0.5s cubic-bezier(0.34,1.56,0.64,1) ${i * 60}ms`,
                  boxShadow: pct > 0.7 ? "0 0 12px rgba(6,182,212,0.3)" : "none",
                  minHeight: d.count > 0 ? 4 : 0
                }} />
              </div>
              <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 9, color: "var(--border-mid)", textAlign: "center" }}>
                {d.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Brand Leaderboard ────────────────────────────────────────────────────────
function BrandLeaderboard({ brands }) {
  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, padding: "20px 24px" }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 16 }}>
        Top Brands
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {brands.map((b, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{
              width: 26, height: 26, borderRadius: "50%",
              background: i === 0 ? "rgba(6,182,212,0.15)" : "var(--bg-deep)",
              border: `1px solid ${i === 0 ? "#06b6d4" : "var(--bg-card)"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "'Space Mono', monospace", fontSize: 10,
              color: i === 0 ? "#06b6d4" : "var(--border-mid)", flexShrink: 0
            }}>
              {i + 1}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-base)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {b.name}
              </div>
            </div>
            <div style={{
              background: "var(--bg-deep)", border: "1px solid var(--border)",
              borderRadius: 99, padding: "2px 8px",
              fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: "var(--border-mid)",
              whiteSpace: "nowrap"
            }}>
              {b.products} {b.products === 1 ? "product" : "products"}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 3, flexShrink: 0 }}>
              <svg width="10" height="10" viewBox="0 0 14 14">
                <path d="M7 1l1.6 3.3 3.6.5-2.6 2.6.6 3.6L7 9.3l-3.2 1.7.6-3.6L1.8 4.8l3.6-.5z" fill="#f59e0b" />
              </svg>
              <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: "#f59e0b" }}>{b.rating.toFixed(1)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── AI Insights ──────────────────────────────────────────────────────────────
function AIInsights({ insights }) {
  const [loading4, setLoading4] = useState4(false);
  const [streamedSummary, setStreamedSummary] = useState4(insights.summary);
  const [streamedOpportunity, setStreamedOpportunity] = useState4(insights.opportunity);

  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14,
      overflow: "hidden", flex: 1
    }}>
      {/* Purple-to-cyan gradient top border */}
      <div style={{ height: 2, background: "linear-gradient(90deg, #818cf8, #06b6d4)" }} />
      <div style={{ padding: "20px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)" }}>
            AI Market Analysis
          </span>
          <span style={{
            background: "rgba(129,140,248,0.1)", border: "1px solid rgba(129,140,248,0.25)",
            borderRadius: 99, padding: "2px 10px",
            fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: "#818cf8"
          }}>
            GPT-4o-mini
          </span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 600, color: "var(--border-mid)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>
              Market Summary
            </div>
            <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-muted)", lineHeight: 1.7, margin: 0 }}>
              {streamedSummary}
            </p>
          </div>
          <div style={{ height: 1, background: "var(--border)" }} />
          <div>
            <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, fontWeight: 600, color: "var(--border-mid)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: 8 }}>
              Opportunity Analysis
            </div>
            <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-muted)", lineHeight: 1.7, margin: 0 }}>
              {streamedOpportunity}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Recommendations ──────────────────────────────────────────────────────────
function Recommendations({ items }) {
  return (
    <div style={{ flex: 1 }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 12 }}>
        Recommendations
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {items.map((rec, i) => (
          <div key={i} style={{
            background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 12,
            padding: "14px 16px", display: "flex", gap: 12, alignItems: "flex-start",
            transition: "border-color 0.2s"
          }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "var(--border-mid)"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "var(--border)"}
          >
            <div style={{
              width: 22, height: 22, borderRadius: "50%",
              background: "rgba(6,182,212,0.12)", border: "1px solid rgba(6,182,212,0.3)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "'Space Mono', monospace", fontSize: 10, color: "#06b6d4",
              flexShrink: 0, marginTop: 1
            }}>
              {i + 1}
            </div>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--text-muted)", lineHeight: 1.6 }}>
              {rec}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Risk Flags ───────────────────────────────────────────────────────────────
function RiskFlags({ risks }) {
  return (
    <div style={{ width: 300, flexShrink: 0 }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 12 }}>
        Risk Flags
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {risks.length === 0 ? (
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "12px 16px", background: "rgba(34,197,94,0.06)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 10 }}>
            <span style={{ color: "#22c55e", fontSize: 14 }}>✓</span>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "#22c55e" }}>No major risks identified</span>
          </div>
        ) : risks.map((risk, i) => (
          <div key={i} style={{
            display: "flex", gap: 10, alignItems: "flex-start",
            padding: "12px 16px",
            background: "rgba(244,63,94,0.05)",
            border: "1px solid rgba(244,63,94,0.15)",
            borderRadius: 10,
            transition: "border-color 0.2s"
          }}
            onMouseEnter={e => e.currentTarget.style.borderColor = "rgba(244,63,94,0.3)"}
            onMouseLeave={e => e.currentTarget.style.borderColor = "rgba(244,63,94,0.15)"}
          >
            <svg width="14" height="14" viewBox="0 0 16 16" style={{ flexShrink: 0, marginTop: 1 }}>
              <path d="M8 1L1 14h14L8 1z" fill="none" stroke="#f43f5e" strokeWidth="1.5" strokeLinejoin="round" />
              <line x1="8" y1="6" x2="8" y2="10" stroke="#f43f5e" strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="8" cy="12" r="0.8" fill="#f43f5e" />
            </svg>
            <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--text-muted)", lineHeight: 1.6 }}>
              {risk}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Footer Accordion ─────────────────────────────────────────────────────────
function FooterAccordion() {
  const [open, setOpen] = useState4(false);
  return (
    <div style={{ borderTop: "1px solid var(--bg-card)", paddingTop: 20 }}>
      <button onClick={() => setOpen(o => !o)} style={{
        background: "none", border: "none", cursor: "pointer",
        display: "flex", alignItems: "center", gap: 8,
        fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--border-mid)",
        padding: 0, transition: "color 0.15s"
      }}
        onMouseEnter={e => e.currentTarget.style.color = "var(--text-dim)"}
        onMouseLeave={e => e.currentTarget.style.color = "var(--border-mid)"}
      >
        <svg width="12" height="12" viewBox="0 0 12 12" style={{ transform: open ? "rotate(90deg)" : "none", transition: "transform 0.2s" }}>
          <path d="M4 2l4 4-4 4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        How estimates are calculated
      </button>
      {open && (
        <div style={{
          marginTop: 12, padding: "16px 20px",
          background: "var(--bg-deep)", border: "1px solid var(--border)", borderRadius: 10
        }}>
          <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: "var(--border-mid)", lineHeight: 2 }}>
            <span style={{ color: "var(--text-dim)" }}>Review Count</span>
            <span style={{ color: "var(--border)" }}> × 0.05 = </span>
            <span style={{ color: "var(--text-dim)" }}>Est. Units Sold/mo</span>
            <span style={{ color: "var(--border)" }}> → </span>
            <span style={{ color: "var(--text-dim)" }}>× Price</span>
            <span style={{ color: "var(--border)" }}> = </span>
            <span style={{ color: "#06b6d4" }}>Est. Revenue</span>
          </div>
          <p style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--border)", margin: "10px 0 0", lineHeight: 1.7 }}>
            Estimates are based on the review velocity multiplier method, a widely-used approximation in Amazon market research. 
            Actual sales may vary significantly based on seasonality, ad spend, pricing changes, and inventory. 
            Low/High ranges represent ±40% confidence intervals. Do not use as financial projections.
          </p>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { DistributionChart, BrandLeaderboard, AIInsights, Recommendations, RiskFlags, FooterAccordion });
