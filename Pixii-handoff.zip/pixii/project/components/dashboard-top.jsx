// NicheScope — Dashboard Hero Cards + Score Gauges

const { useState, useEffect, useRef: useRef2 } = React;

// ─── Utility ──────────────────────────────────────────────────────────────────
function fmt(n) {
  if (n >= 1000000) return "$" + (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return "$" + (n / 1000).toFixed(0) + "K";
  return "$" + n.toLocaleString();
}

function useCountUp(target, duration = 1200) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let start = null;
    const step = (ts) => {
      if (!start) start = ts;
      const p = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      setVal(Math.round(ease * target));
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target]);
  return val;
}

// ─── Stars ────────────────────────────────────────────────────────────────────
function Stars({ rating }) {
  return (
    <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
      {[1, 2, 3, 4, 5].map(i => {
        const fill = Math.min(1, Math.max(0, rating - (i - 1)));
        return (
          <svg key={i} width="14" height="14" viewBox="0 0 14 14" fill="none">
            <defs>
              <linearGradient id={`sg-${i}-${Math.random().toString(36).slice(2)}`} x1="0" x2="1" y1="0" y2="0">
                <stop offset={`${fill * 100}%`} stopColor="#f59e0b" />
                <stop offset={`${fill * 100}%`} stopColor="var(--bg-card)" />
              </linearGradient>
            </defs>
            <path d="M7 1l1.6 3.3 3.6.5-2.6 2.6.6 3.6L7 9.3l-3.2 1.7.6-3.6L1.8 4.8l3.6-.5z"
              fill={fill === 1 ? "#f59e0b" : fill === 0 ? "var(--bg-card)" : `url(#sg-${i})`}
              stroke="#f59e0b" strokeWidth="0.5" strokeOpacity={fill > 0 ? 0.5 : 0.2}
            />
          </svg>
        );
      })}
    </div>
  );
}

// ─── Hero Cards ───────────────────────────────────────────────────────────────
function HeroCards({ data, darkMode }) {
  const rev = useCountUp(data.estMonthlyRevenue.mid, 1400);
  const price = useCountUp(data.avgPrice * 100, 1000);
  const rating = useCountUp(data.avgRating * 10, 900);
  const reviews = useCountUp(data.reviewsAnalyzed, 1300);

  const cards = [
    {
      label: "Est. Monthly Revenue",
      sub: "Mid estimate",
      main: fmt(rev),
      mainColor: "#06b6d4",
      extra: (
        <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: "var(--border-mid)" }}>
          Low {fmt(data.estMonthlyRevenue.low)} — High {fmt(data.estMonthlyRevenue.high)}
        </span>
      ),
      accentColor: "#06b6d4",
    },
    {
      label: "Avg. Price",
      sub: "Across top 10",
      main: (
        <span>
          <span style={{ color: "#06b6d4", fontSize: "0.6em" }}>$</span>
          {(price / 100).toFixed(2)}
        </span>
      ),
      mainColor: "var(--text-base)",
      extra: <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--border-mid)" }}>Top 10 products</span>,
      accentColor: null,
    },
    {
      label: "Avg. Rating",
      sub: "Customer score",
      main: (rating / 10).toFixed(1),
      mainColor: "var(--text-base)",
      extra: <Stars rating={data.avgRating} />,
      accentColor: null,
    },
    {
      label: "Reviews Analyzed",
      sub: `across ${data.productsAnalyzed} products`,
      main: reviews.toLocaleString(),
      mainColor: "var(--text-base)",
      extra: <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--border-mid)" }}>across {data.productsAnalyzed} products</span>,
      accentColor: "#f59e0b",
    },
  ];

  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(4, 1fr)",
      gap: 16
    }}>
      {cards.map((card, i) => (
        <div key={i} style={{
          background: "var(--bg-card)",
          border: "1px solid var(--border)",
          borderRadius: 14,
          padding: "22px 24px",
          position: "relative",
          overflow: "hidden",
          transition: "border-color 0.2s"
        }}
          onMouseEnter={e => e.currentTarget.style.borderColor = "var(--border-mid)"}
          onMouseLeave={e => e.currentTarget.style.borderColor = "var(--border)"}
        >
          {card.accentColor && (
            <div style={{
              position: "absolute", top: 0, left: 0, right: 0, height: 2,
              background: card.accentColor,
              boxShadow: `0 0 12px ${card.accentColor}88`
            }} />
          )}
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--text-dim)", marginBottom: 8, letterSpacing: "0.02em" }}>
            {card.label}
          </div>
          <div style={{
            fontFamily: "'Space Mono', monospace",
            fontSize: "clamp(22px, 2.5vw, 32px)",
            fontWeight: 700,
            color: card.mainColor,
            lineHeight: 1.1,
            marginBottom: 6,
            letterSpacing: "-0.02em"
          }}>
            {card.main}
          </div>
          {card.extra}
        </div>
      ))}
    </div>
  );
}

// ─── Semicircle Gauge ─────────────────────────────────────────────────────────
function SemiGauge({ score, label, labelColor, type, factors }) {
  const [animated, setAnimated] = useState(0);
  useEffect(() => {
    let s = null;
    const step = (ts) => {
      if (!s) s = ts;
      const p = Math.min((ts - s) / 1000, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      setAnimated(ease * score);
      if (p < 1) requestAnimationFrame(step);
    };
    const t = setTimeout(() => requestAnimationFrame(step), 300);
    return () => clearTimeout(t);
  }, [score]);

  const r = 70;
  const cx = 100, cy = 92;

  function polar(centerX, centerY, radius, angleRad) {
    return [centerX + radius * Math.cos(angleRad), centerY + radius * Math.sin(angleRad)];
  }

  // Semicircle: left end = angle 180° (π), right end = angle 0°
  // We draw from LEFT → RIGHT as score increases (0%=left, 100%=right)
  // SVG sweep-flag=0 means counter-clockwise — going from π toward 0 is CCW in SVG
  const pct = animated / 100;
  // left endpoint (always fixed start)
  const [sx, sy] = polar(cx, cy, r, Math.PI);
  // end point sweeps from left (π) toward right (0): angle = π*(1-pct)
  const endA = Math.PI * (1 - pct);
  const [ex, ey] = polar(cx, cy, r, endA);
  // large-arc flag: need 1 when pct > 0.5 (arc > 180° would be wrong here — max is 180°)
  // Since total arc is exactly π (180°), large-arc is always 0 for pct ≤ 1
  const largeArc = 0;

  // Color: competitiveness goes red as score increases, opportunity goes green
  function getColor(p) {
    if (type === "competition") {
      if (p < 0.4) return "#06b6d4";
      if (p < 0.6) return "#f59e0b";
      return "#f43f5e";
    } else {
      if (p < 0.35) return "#f43f5e";
      if (p < 0.6) return "#f59e0b";
      return "#22c55e";
    }
  }

  const arcColor = getColor(score / 100);

  return (
    <div style={{
      background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14,
      padding: "24px", flex: 1
    }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-dim)", marginBottom: 12 }}>
        {type === "competition" ? "Market Competitiveness" : "Entry Opportunity"}
      </div>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
        <svg width={200} height={114} viewBox="0 0 200 114">
          {/* Background track: left to right, clockwise */}
          <path
            d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
            fill="none" stroke="var(--bg-deep)" strokeWidth={10} strokeLinecap="round"
          />
          {/* Filled arc: left → animated position, counter-clockwise (sweep=0) */}
          {animated > 0.5 && (
            <path
              d={`M ${sx} ${sy} A ${r} ${r} 0 ${pct > 0.5 ? 1 : 0} 1 ${ex} ${ey}`}
              fill="none"
              stroke={arcColor}
              strokeWidth={10}
              strokeLinecap="round"
              style={{ filter: `drop-shadow(0 0 6px ${arcColor}88)` }}
            />
          )}
          {/* Tick marks */}
          {[0, 25, 50, 75, 100].map(tick => {
            const a = Math.PI - (Math.PI * tick / 100);
            const [ox, oy] = polar(cx, cy, r + 13, a);
            const [ix, iy] = polar(cx, cy, r + 6, a);
            return <line key={tick} x1={ix} y1={iy} x2={ox} y2={oy} stroke="var(--border)" strokeWidth={1.5} />;
          })}
          {/* 0 / 100 labels */}
          <text x={cx - r - 8} y={cy + 16} textAnchor="middle" fill="var(--border)" fontSize={9} fontFamily="Space Mono">0</text>
          <text x={cx + r + 8} y={cy + 16} textAnchor="middle" fill="var(--border)" fontSize={9} fontFamily="Space Mono">100</text>
        </svg>
        <div style={{ marginTop: -20, textAlign: "center" }}>
          <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 36, fontWeight: 700, color: "var(--text-base)", lineHeight: 1 }}>
            {Math.round(animated)}
          </div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: labelColor, fontWeight: 600, marginTop: 4 }}>
            {label}
          </div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 20 }}>
        {factors.map((f, i) => (
          <div key={i}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--text-dim)" }}>{f.name}</span>
              <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: "var(--text-muted)" }}>{f.value}</span>
            </div>
            <div style={{ height: 4, background: "var(--bg-deep)", borderRadius: 99, overflow: "hidden" }}>
              <div style={{ height: "100%", width: `${f.value}%`, background: "var(--border)", borderRadius: 99, transition: "width 1s ease" }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScoreGauges({ data }) {
  return (
    <div style={{ display: "flex", gap: 16 }}>
      <SemiGauge
        score={data.competitiveness.score}
        label={data.competitiveness.label}
        labelColor="#f43f5e"
        type="competition"
        factors={data.competitiveness.factors}
      />
      <SemiGauge
        score={data.opportunity.score}
        label={data.opportunity.label}
        labelColor="#f59e0b"
        type="opportunity"
        factors={data.opportunity.factors}
      />
    </div>
  );
}

Object.assign(window, { HeroCards, ScoreGauges, Stars, fmt, useCountUp });
