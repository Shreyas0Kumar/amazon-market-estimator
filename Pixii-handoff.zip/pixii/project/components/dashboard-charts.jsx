// NicheScope — Products Table + Charts

const { useState: useState3, useEffect: useEffect3, useRef: useRef3 } = React;

// ─── Product Thumbnail placeholder ───────────────────────────────────────────
function ProductThumb({ rank }) {
  const hues = [200, 160, 280, 40, 320, 180, 220, 140, 260, 80];
  const h = hues[rank - 1] || 200;
  return (
    <div style={{
      width: 36, height: 36, borderRadius: 6, flexShrink: 0,
      background: `oklch(0.25 0.04 ${h})`,
      border: `1px solid oklch(0.35 0.05 ${h})`,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'Space Mono', monospace", fontSize: 10, color: `oklch(0.6 0.1 ${h})`
    }}>
      {rank}
    </div>
  );
}

// ─── Revenue Mini Bar ─────────────────────────────────────────────────────────
function RevBar({ low, mid, high }) {
  const total = high * 1.1;
  const lowPct = (low / total) * 100;
  const midPct = ((mid - low) / total) * 100;
  const highPct = ((high - mid) / total) * 100;
  return (
    <div>
      <div style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: "#06b6d4", marginBottom: 3 }}>
        {fmt(mid)}
      </div>
      <div style={{ display: "flex", height: 3, borderRadius: 99, overflow: "hidden", width: 100 }}>
        <div style={{ width: `${lowPct}%`, background: "var(--border)" }} />
        <div style={{ width: `${midPct}%`, background: "#06b6d4" }} />
        <div style={{ width: `${highPct}%`, background: "#0e7490" }} />
      </div>
    </div>
  );
}

// ─── Products Table ───────────────────────────────────────────────────────────
function ProductsTable({ products }) {
  const [sortKey, setSortKey] = useState3("rank");
  const [sortDir, setSortDir3] = useState3(1);
  const [hoverRow, setHoverRow] = useState3(null);

  const cols = [
    { key: "rank", label: "#", w: 36 },
    { key: "name", label: "Product", w: "auto" },
    { key: "brand", label: "Brand", w: 110 },
    { key: "price", label: "Price", w: 70 },
    { key: "rating", label: "Rating", w: 80 },
    { key: "reviews", label: "Reviews", w: 80 },
    { key: "revenue", label: "Est. Revenue", w: 130 },
  ];

  function handleSort(key) {
    if (key === sortKey) setSortDir3(d => -d);
    else { setSortKey(key); setSortDir3(1); }
  }

  const sorted = [...products].sort((a, b) => {
    let av = a[sortKey], bv = b[sortKey];
    if (sortKey === "revenue") { av = a.revenue.mid; bv = b.revenue.mid; }
    if (typeof av === "string") return av.localeCompare(bv) * sortDir;
    return (av - bv) * sortDir;
  });

  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, overflow: "hidden" }}>
      <div style={{ padding: "18px 20px 12px", borderBottom: "1px solid var(--border)" }}>
        <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)" }}>
          Top Products
        </span>
      </div>
      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              {cols.map(col => (
                <th key={col.key} onClick={() => handleSort(col.key)} style={{
                  padding: "10px 16px",
                  textAlign: col.key === "rank" ? "center" : "left",
                  fontFamily: "'DM Sans', sans-serif",
                  fontSize: 11, color: "var(--border-mid)", fontWeight: 500,
                  letterSpacing: "0.05em", textTransform: "uppercase",
                  cursor: "pointer", userSelect: "none",
                  background: "var(--bg-inset)",
                  whiteSpace: "nowrap",
                  width: col.w === "auto" ? undefined : col.w,
                  transition: "color 0.15s"
                }}
                  onMouseEnter={e => e.currentTarget.style.color = "var(--text-muted)"}
                  onMouseLeave={e => e.currentTarget.style.color = "var(--border-mid)"}
                >
                  {col.label}
                  {sortKey === col.key && (
                    <span style={{ marginLeft: 4, color: "#06b6d4" }}>{sortDir === 1 ? "↑" : "↓"}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map((p, i) => (
              <tr key={p.rank}
                onMouseEnter={() => setHoverRow(i)}
                onMouseLeave={() => setHoverRow(null)}
                style={{
                  borderTop: "1px solid var(--bg-deep)",
                  background: hoverRow === i ? "var(--bg-inset)" : "transparent",
                  transition: "background 0.15s",
                  position: "relative"
                }}>
                {/* Cyan left border on hover */}
                <td style={{ padding: "11px 16px", textAlign: "center", position: "relative" }}>
                  {hoverRow === i && (
                    <div style={{
                      position: "absolute", left: 0, top: 0, bottom: 0,
                      width: 2, background: "#06b6d4",
                      boxShadow: "0 0 8px #06b6d4"
                    }} />
                  )}
                  <ProductThumb rank={p.rank} />
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{
                      fontFamily: "'DM Sans', sans-serif", fontSize: 13, color: "var(--text-base)",
                      maxWidth: 300, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                      display: "block"
                    }}>{p.name}</span>
                    {p.sponsored && (
                      <span style={{
                        fontFamily: "'DM Sans', sans-serif", fontSize: 10,
                        color: "var(--border-mid)", background: "var(--bg-deep)",
                        border: "1px solid var(--border)", borderRadius: 4,
                        padding: "1px 6px", flexShrink: 0
                      }}>Sponsored</span>
                    )}
                  </div>
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 12, color: "var(--text-dim)" }}>{p.brand}</span>
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 13, color: "var(--text-base)" }}>
                    ${p.price.toFixed(2)}
                  </span>
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: "#f59e0b" }}>
                      {p.rating.toFixed(1)}
                    </span>
                    <svg width="10" height="10" viewBox="0 0 14 14">
                      <path d="M7 1l1.6 3.3 3.6.5-2.6 2.6.6 3.6L7 9.3l-3.2 1.7.6-3.6L1.8 4.8l3.6-.5z"
                        fill="#f59e0b" />
                    </svg>
                  </div>
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 12, color: "var(--text-muted)" }}>
                    {p.reviews.toLocaleString()}
                  </span>
                </td>
                <td style={{ padding: "11px 16px" }}>
                  <RevBar low={p.revenue.low} mid={p.revenue.mid} high={p.revenue.high} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Revenue Bar Chart ────────────────────────────────────────────────────────
function RevenueChart({ products }) {
  const [hovered, setHovered] = useState3(null);
  const top5 = products.slice(0, 5);
  const maxVal = Math.max(...top5.map(p => p.revenue.high));

  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, padding: "20px 24px", flex: 1 }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 16 }}>
        Revenue by Product
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {top5.map((p, i) => {
          const lowW = (p.revenue.low / maxVal) * 100;
          const midW = (p.revenue.mid / maxVal) * 100;
          const highW = (p.revenue.high / maxVal) * 100;
          const name = p.name.split(" ").slice(0, 3).join(" ");
          return (
            <div key={i} onMouseEnter={() => setHovered(i)} onMouseLeave={() => setHovered(null)}
              style={{ cursor: "default" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--text-dim)", maxWidth: 150, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {name}…
                </span>
                <span style={{ fontFamily: "'Space Mono', monospace", fontSize: 11, color: hovered === i ? "#06b6d4" : "var(--border-mid)" }}>
                  {fmt(p.revenue.mid)}
                </span>
              </div>
              <div style={{ position: "relative", height: 22, background: "var(--bg-deep)", borderRadius: 4, overflow: "hidden" }}>
                <div style={{ position: "absolute", top: 0, left: 0, height: "100%", width: `${highW}%`, background: "#1e3a4a", borderRadius: 4 }} />
                <div style={{ position: "absolute", top: 0, left: 0, height: "100%", width: `${midW}%`, background: "#0891b2", borderRadius: 4 }} />
                <div style={{ position: "absolute", top: 0, left: 0, height: "100%", width: `${lowW}%`, background: "var(--border)", borderRadius: 4 }} />
              </div>
            </div>
          );
        })}
        <div style={{ display: "flex", gap: 12, marginTop: 4 }}>
          {[["var(--border)", "Low"], ["#0891b2", "Mid"], ["#1e3a4a", "High"]].map(([c, l]) => (
            <div key={l} style={{ display: "flex", alignItems: "center", gap: 5 }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: c }} />
              <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 10, color: "var(--border-mid)" }}>{l}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Scatter Chart ────────────────────────────────────────────────────────────
function ScatterChart({ products }) {
  const [tooltip, setTooltip] = useState3(null);
  const svgRef = useRef3(null);

  const W = 320, H = 220, PAD = { top: 16, right: 16, bottom: 36, left: 44 };
  const chartW = W - PAD.left - PAD.right;
  const chartH = H - PAD.top - PAD.bottom;

  const prices = products.map(p => p.price);
  const ratings = products.map(p => p.rating);
  const maxReviews = Math.max(...products.map(p => p.reviews));

  const minP = Math.min(...prices) - 5, maxP = Math.max(...prices) + 5;
  const minR = Math.min(...ratings) - 0.2, maxR = Math.max(...ratings) + 0.1;

  const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length;
  const avgRating = ratings.reduce((a, b) => a + b, 0) / ratings.length;

  const xScale = v => ((v - minP) / (maxP - minP)) * chartW;
  const yScale = v => chartH - ((v - minR) / (maxR - minR)) * chartH;
  const rScale = v => Math.sqrt(v / maxReviews) * 16 + 4;

  return (
    <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 14, padding: "20px 24px", flex: 1, position: "relative" }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 8 }}>
        Price vs. Rating
      </div>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--border)", marginBottom: 12 }}>
        Dot size = review count
      </div>
      <div style={{ position: "relative", display: "inline-block" }}>
        <svg width={W} height={H} style={{ overflow: "visible" }}>
          <g transform={`translate(${PAD.left}, ${PAD.top})`}>
            {/* Grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map(t => (
              <line key={t} x1={0} y1={t * chartH} x2={chartW} y2={t * chartH}
                stroke="var(--bg-card)" strokeWidth={1} />
            ))}
            {/* Avg lines */}
            <line x1={xScale(avgPrice)} y1={0} x2={xScale(avgPrice)} y2={chartH}
              stroke="var(--border-mid)" strokeWidth={1} strokeDasharray="4 3" />
            <line x1={0} y1={yScale(avgRating)} x2={chartW} y2={yScale(avgRating)}
              stroke="var(--border-mid)" strokeWidth={1} strokeDasharray="4 3" />
            <text x={xScale(avgPrice) + 4} y={10} fill="var(--border-mid)" fontSize={9} fontFamily="DM Sans">avg price</text>
            <text x={4} y={yScale(avgRating) - 4} fill="var(--border-mid)" fontSize={9} fontFamily="DM Sans">avg rating</text>

            {/* Dots */}
            {products.map((p, i) => {
              const x = xScale(p.price);
              const y = yScale(p.rating);
              const r = rScale(p.reviews);
              const isTop = i === 0;
              return (
                <circle key={i} cx={x} cy={y} r={r}
                  fill={isTop ? "#f59e0b" : "rgba(6,182,212,0.7)"}
                  stroke={isTop ? "#f59e0baa" : "rgba(6,182,212,0.3)"}
                  strokeWidth={isTop ? 2 : 1}
                  style={{ cursor: "pointer", filter: isTop ? "drop-shadow(0 0 6px #f59e0b88)" : tooltip === i ? "drop-shadow(0 0 4px #06b6d488)" : "none", transition: "r 0.2s" }}
                  onMouseEnter={() => setTooltip(i)}
                  onMouseLeave={() => setTooltip(null)}
                />
              );
            })}

            {/* Axes */}
            <line x1={0} y1={chartH} x2={chartW} y2={chartH} stroke="var(--border)" strokeWidth={1} />
            <line x1={0} y1={0} x2={0} y2={chartH} stroke="var(--border)" strokeWidth={1} />
            {[minP + 5, avgPrice, maxP - 5].map(v => (
              <text key={v} x={xScale(v)} y={chartH + 14} textAnchor="middle"
                fill="var(--border-mid)" fontSize={9} fontFamily="Space Mono">${Math.round(v)}</text>
            ))}
            {[minR + 0.2, avgRating, maxR - 0.1].map(v => (
              <text key={v} x={-8} y={yScale(v) + 4} textAnchor="end"
                fill="var(--border-mid)" fontSize={9} fontFamily="Space Mono">{v.toFixed(1)}</text>
            ))}
          </g>
        </svg>
        {/* Tooltip */}
        {tooltip !== null && (
          <div style={{
            position: "absolute", top: 8, right: 8,
            background: "var(--bg-deep)", border: "1px solid var(--border)",
            borderRadius: 8, padding: "8px 12px",
            fontFamily: "'DM Sans', sans-serif", fontSize: 11, color: "var(--text-muted)",
            pointerEvents: "none", maxWidth: 160,
            boxShadow: "0 4px 16px rgba(0,0,0,0.4)"
          }}>
            <div style={{ color: "var(--text-base)", fontWeight: 600, marginBottom: 4, lineHeight: 1.3 }}>
              {products[tooltip].name.split(" ").slice(0, 4).join(" ")}
            </div>
            <div>Price: <span style={{ color: "#06b6d4", fontFamily: "'Space Mono', monospace" }}>${products[tooltip].price}</span></div>
            <div>Rating: <span style={{ color: "#f59e0b", fontFamily: "'Space Mono', monospace" }}>{products[tooltip].rating}</span></div>
            <div>Reviews: <span style={{ color: "var(--text-muted)", fontFamily: "'Space Mono', monospace" }}>{products[tooltip].reviews.toLocaleString()}</span></div>
          </div>
        )}
      </div>
    </div>
  );
}

Object.assign(window, { ProductsTable, RevenueChart, ScatterChart });
